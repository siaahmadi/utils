function [idx, varargout] = restrict(obj, sorted, refValues, varargin)
%RESTRICT Restrict values to within the intervals of the ivlset object
%
% [idx, varargout] = RESTRICT(obj, sorted, refValues, varargin)
%
%  INPUT:
%  sorted    Can take only one value 'unsorted'. Indicate this if refValues
%            are unsorted. Otherwise, it will be assumed that they are
%            sorted.
%
%  refValues must be in the same unit as the intervals of the ivlset object
%  
%  an arbitrary number of inputs may follow refValues. Each such input must
%  be the same size as refValues. refValues will be treated as the "time
%  stamps" into each input.
%
% OUTPUT:
% idx     binary indexing into refValues that fall within the intervals of
%         the ivlset object
% 
% each output after idx will be the restricted values taken from the
% corresponding input values.
%
% EXAMPLE:
% [idx, valid_timestamps] = ivl.restrict(T, T);
%
% after this we have:
% valid_timestamps == T(idx);

% Siavash Ahmadi


if numel(obj) > 1
	idx = arrayfun(@(o) o.restrict(refValues), obj, 'un', 0);
	return;
end

if ischar(sorted) && strcmpi(sorted, 'unsorted')
	sorted = false;
elseif isnumeric(sorted)
	if exist('refValues', 'var')
		varargin = [{refValues}, varargin{:}];
	end
	refValues = sorted;
	sorted = true;
else
	error('|sorted| must either be specified as ''unsorted'' or skipped.');
end

iCollapsed = false;

if ~obj.iscollapsed()
	obj.collapse('|');
	iCollapsed = true;
end

[b, e] = obj.toIvl();

if sorted
	[idx, inlineIdx] = findStartEnd(refValues, b, e);
else
	idx = arrayfun(@(b, e) b <= refValues(:) & refValues(:) <= e, b, e, 'UniformOutput', false);
	inlineIdx = sum(cat(2, idx{:}), 2)>0;
end

varargout = cell(size(varargin));
for i = 1:nargin - 2 - double(~sorted)
	varargout{i} = varargin{i}(inlineIdx);
end

if iCollapsed
	obj.uncollapse();
end

function [idx, inlineIdx] = findStartEnd(refValues, b, e)
inlineIdx = false(size(refValues));
idx = repmat({false(size(inlineIdx))}, length(b), 1);

if isempty(refValues)
	return;
elseif numel(refValues) == 1
	idx = arrayfun(@(b, e) b <= refValues(:) & refValues(:) <= e, b, e, 'UniformOutput', false);
	inlineIdx = sum(cat(2, idx{:}), 2)>0;
	return;
end

% find indices
idx_begin = binsearch_approx(refValues, b);
% idx_begin elements can be negative (approximate values found), positive
% (exact values found), or 0 (out-of-range values).
% For positives, all good.
% For negatives, make them positive and add an index so only least value
% larger than b(i) will be included for idx_begin(i) < 0
idx_begin(idx_begin<0) = abs(idx_begin(idx_begin<0))+1;
% For out-of-range values set them to 1 only if they fall to the left of
% the refValues:
ilt = b(idx_begin==0)<refValues(1); % ilt==index of less-than
idx_begin(ilt) = 1;

idx_end = abs(binsearch_approx(refValues, e, 1));
% in a similar fashion to idx_begin, only set those idx_end's that are to the right of
% refValues:
igt = e(idx_end==0)>refValues(end); % igt==index of greater-than
idx_end(igt) = length(refValues);

for i = 1:length(idx_begin)
	if idx_begin(i) > 0 && idx_end(i) > 0 && idx_end(i) >= idx_begin(i) % if binsearch_approx's return values are valid indices (i.e. keys found)
		inlineIdx(idx_begin(i):idx_end(i)) = true;
		idx{i}(idx_begin(i):idx_end(i)) = true;
	end
end