function [idx, varargout] = restrict_approx(obj, values, varargin)

