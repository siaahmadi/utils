function I = iscollapsed(obj)

I = obj.inCollapsedState;